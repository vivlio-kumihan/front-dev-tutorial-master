// var, let, const
let name = 'Tom';
name = 'Tim';
console.log('hello ' + name);

// データ型：Number, String, Boolean, Undefined, Null, Symbol

// 動的型付け言語
let variable = 'str';
variable = 12;
variable = false;
variable = undefined;

console.log(typeof variable);

// 静的型付け言語
// int num = 12;