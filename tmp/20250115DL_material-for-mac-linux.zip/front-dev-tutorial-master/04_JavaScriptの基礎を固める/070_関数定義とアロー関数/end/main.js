const hello = (name, age) => `${name} ${age}`;

const arry = [1,2,3,4,5,6];

arry.forEach(value => console.log(value));
