let hello = 'hello world';
console.log(hello.length);